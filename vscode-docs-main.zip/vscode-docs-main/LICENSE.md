Copyright (c) Microsoft Corporation. All rights reserved. Distributed under the following terms:

1.	Documentation is licensed under the [Creative Commons Attribution 3.0 United States License](https://creativecommons.org/licenses/by/3.0/us/legalcode). Code is licensed under the [MIT License](https://opensource.org/licenses/MIT).

2.	This license does not grant you rights to use any trademarks or logos of Microsoft. For Microsoft’s general trademark guidelines, go to  https://go.microsoft.com/fwlink/?LinkID=254653.

