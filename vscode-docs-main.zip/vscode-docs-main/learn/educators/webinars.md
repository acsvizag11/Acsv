---
Order: 7
Area: educators
TOCTitle: Webinars
ContentId: bea23e2b-17c4-45d5-9233-471610fa6621
PageTitle: Visual Studio Code Webinars
DateApproved: 10/22/2020
MetaDescription: Visual Studio Code Webinars
---
# Visual Studio Code Webinars

Check out previous talks about using VS Code in classrooms or other education scenarios.

## Ignite Conference 2020

With Visual Studio Code, you can code from anywhere - including your own browser! We'll show you how to start in any programming language you like, personalize the editor to fit your style, and even invite your peers to code with you in real time.

<iframe src="https://youtube.com/embed/JctES9LOFx8?rel=0&amp;disablekb=0&amp;modestbranding=1&amp;showinfo=0" frameborder="0" allowfullscreen title="Visual Studio Code - Your editor everywhere"></iframe>
30 minutes
