---
Order: 13
Area: python
TOCTitle: Create containers
ContentId: 4e45a3f6-b72d-4647-82a5-22f7ee593d47
PageTitle: Create Docker containers for Python web apps in Visual Studio Code
DateApproved: 02/1/2024
MetaDescription: How to create Docker containers for Python web apps using the VS Code Docker extension
MetaSocialImage: images/tutorial/social.png
---
# Create Docker containers for Python

This page is redirected to /docs/containers/quickstart-python.md and only exists to keep the "Create containers" TOC item.
