---
Order: 7
Area: cpp
TOCTitle: Build with CMake
ContentId: eaef83f6-294a-4bb6-a2fe-bc8ffb3b33bf
PageTitle: Build with CMake
DateApproved: 12/6/2022
MetaDescription: Learn how to use CMake with Visual Studio Code
---

# Build with CMake

This page redirects to https://github.com/microsoft/vscode-cmake-tools/blob/main/docs/README.md and only exists to present the "Build with CMake" TOC entry.
