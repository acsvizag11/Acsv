---
Order: 3
Area: remote
TOCTitle: Dev Containers
PageTitle: Developing inside a Container using Visual Studio Code Remote Development
ContentId: 4f0942be-6808-4252-8940-b9e9688792af
MetaDescription: Developing inside a Container using Visual Studio Code Remote Development
DateApproved: 04/04/2024
---
# Dev Containers

This page is redirected to /docs/devcontainers/containers.md and only exists to keep the "Dev Containers" TOC item.
