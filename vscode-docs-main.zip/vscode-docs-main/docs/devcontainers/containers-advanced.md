---
Order: 12
Area: devcontainers
TOCTitle: Advanced Containers
PageTitle: Advanced Container Configuration
ContentId: f180ac25-1d59-47ec-bad2-3ccbf214bbd8
MetaDescription: Advanced setup for using the VS Code Dev Containers extension
DateApproved: 04/04/2024
---
# Advanced Container Configuration

This page is redirected to /remote/advancedcontainers/overview.md and only exists to keep the "Advanced Containers" TOC item.
