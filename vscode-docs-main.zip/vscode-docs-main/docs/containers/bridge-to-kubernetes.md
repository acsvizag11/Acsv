---
Order: 11
Area: containers
TOCTitle: Develop with Kubernetes
ContentId: 80bd336b-0d2d-4d63-a771-8b3ea22a64d3
PageTitle: Use Bridge to Kubernetes to run and debug locally with Kubernetes
DateApproved: 02/1/2024
MetaDescription: Learn how to use Bridge to Kubernetes.
---

# Develop with Kubernetes

This page is redirected to https://learn.microsoft.com/visualstudio/bridge/bridge-to-kubernetes-vs-code and only exists to keep the "Develop with Kubernetes" TOC item.
