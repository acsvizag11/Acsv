---
Order: 4
Area: azure
TOCTitle: Docker
ContentId: 42F8B9F8-BD03-4159-9479-17C5BDE30531
PageTitle: Working with Docker in Visual Studio Code
DateApproved: 02/1/2024
MetaDescription: Working with Docker containers in Visual Studio Code.
---
# Working with Docker

This page is redirected to /docs/containers/overview.md and only exists to keep the "Docker" TOC item.
