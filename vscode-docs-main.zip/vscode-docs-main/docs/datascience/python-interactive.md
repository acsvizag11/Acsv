---
Order: 4
Area: datascience
TOCTitle: Python Interactive
ContentId: 09645514-3c23-49ec-8e27-71831bc06ce7
PageTitle: Working with Jupyter code cells in the Python Interactive window
DateApproved: 1/9/2023
MetaDescription: Working with Jupyter code cells in the Python Interactive window
MetaSocialImage: images/tutorial/social.png
---

# How to use Python Interactive in Jupyter

This page is redirected to /docs/python/jupyter-support-py.md and only exists to keep the "Python Interactive" TOC item.
